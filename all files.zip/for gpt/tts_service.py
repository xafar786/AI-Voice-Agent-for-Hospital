import base64
from openai_client import client
from config import OPENAI_TTS_MODEL, TTS_VOICE

def synthesize_tts_base64(text: str) -> tuple[str, str]:
    audio_resp = client.audio.speech.create(
        model=OPENAI_TTS_MODEL,
        voice=TTS_VOICE,
        input=text,
    )
    audio_bytes = audio_resp.read()
    return base64.b64encode(audio_bytes).decode("utf-8"), "audio/mpeg"