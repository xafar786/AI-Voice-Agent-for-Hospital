from openai_client import client
from config import OPENAI_STT_MODEL

def transcribe_audio_bytes(audio_bytes: bytes, filename: str = "audio.wav") -> str:
    resp = client.audio.transcriptions.create(
        model=OPENAI_STT_MODEL,
        file=(filename, audio_bytes),
        # language="ur",  # optional hint
    )
    return (resp.text or "").strip()