import json
from openai_client import client
from config import OPENAI_LLM_MODEL
from domain.intents import INTENT_SCHEMA_DESCRIPTION
from schemas import IntentResult

def detect_intent(transcript: str) -> IntentResult:
    prompt = f"{INTENT_SCHEMA_DESCRIPTION}\n\nUser transcript:\n{transcript}\n"

    resp = client.responses.create(
        model=OPENAI_LLM_MODEL,
        input=prompt,
        text={"format": {"type": "json_object"}},
    )

    raw = resp.output_text.strip()
    data = json.loads(raw)

    return IntentResult(
        intent=data.get("intent", "other"),
        confidence=float(data.get("confidence", 0.7)),
        entities=dict(data.get("entities", {}) or {}),
    )